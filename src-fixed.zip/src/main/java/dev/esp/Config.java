package dev.esp;

import java.util.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public final class Config {
    public static boolean storageEsp = false, blockEsp = false, playerEsp = false, blockTracers = false, mobTracers = false, itemTracers = false, playerTracers = false;
    public static final Set<Block> CUSTOM = new LinkedHashSet<>();
    public static int radius = 24;
    public static final int[] RADII = {16, 32, 64, 96, 128, 192};
    public static final int PLAYER_COLOR = 0xFF4D6D;

    public record Group(String name, int color, Block... blocks) {}

    public static final List<Group> GROUPS = List.of(
        new Group("Алмазы", 0x33E6FF, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE),
        new Group("Золото", 0xFFD83D, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE),
        new Group("Железо", 0xE8C9A8, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE),
        new Group("Изумруды", 0x3DFF7A, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE),
        new Group("Редстоун", 0xFF3B3B, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE),
        new Group("Лазурит", 0x3D5BFF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE),
        new Group("Уголь", 0x9AA0A6, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE),
        new Group("Медь", 0xFF8A4D, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE),
        new Group("Незерит", 0xB06CFF, Blocks.ANCIENT_DEBRIS),
        new Group("Сундуки", 0xFFB347, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.BARREL),
        new Group("Спавнеры", 0xFF4DD8, Blocks.SPAWNER),
        new Group("Лава", 0xFF6A00, Blocks.LAVA)
    );

    public static final Set<Group> ENABLED = new HashSet<>(List.of(GROUPS.get(0)));
    public static final Map<Block, Integer> STORAGE = new HashMap<>();
    static {
        for (Block b : new Block[]{Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL}) STORAGE.put(b, 0xFFB347);
        STORAGE.put(Blocks.ENDER_CHEST, 0xB06CFF);
        for (Block b : new Block[]{Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX,
            Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX,
            Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.LIGHT_GRAY_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX,
            Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX,
            Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX}) STORAGE.put(b, 0xFF4DD8);
        for (Block b : new Block[]{Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER}) STORAGE.put(b, 0x9AA0A6);
        for (Block b : new Block[]{Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER}) STORAGE.put(b, 0xFF8A3D);
    }

    private static final Map<Block, Group> LOOKUP = new HashMap<>();
    static { for (Group g : GROUPS) for (Block b : g.blocks()) LOOKUP.put(b, g); }

    public static Group lookup(Block b) { return LOOKUP.get(b); }

    /** Цвет подсветки блока или -1, если блок не выбран. */
    public static int wantedColor(Block b) {
        if (storageEsp) { Integer sc = STORAGE.get(b); if (sc != null) return sc; }
        Group g = LOOKUP.get(b);
        if (g != null && ENABLED.contains(g)) return g.color();
        if (CUSTOM.contains(b)) return colorOf(b);
        return -1;
    }

    public static int colorOf(Block b) {
        Group g = LOOKUP.get(b);
        if (g != null) return g.color();
        var key = BuiltInRegistries.BLOCK.getKey(b);
        float h = (Math.abs(key.getPath().hashCode()) % 360) / 360f;
        return Mth.hsvToRgb(h, 0.75f, 1f);
    }

    public static void nextRadius() {
        for (int i = 0; i < RADII.length; i++) if (RADII[i] == radius) { radius = RADII[(i + 1) % RADII.length]; return; }
        radius = RADII[0];
    }
}
