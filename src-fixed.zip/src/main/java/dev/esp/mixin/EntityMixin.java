package dev.esp.mixin;

import dev.esp.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Цвет контура игроков при Player ESP. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void esp$color(CallbackInfoReturnable<Integer> cir) {
        if (Config.playerEsp && (Object) this instanceof Player p && p != Minecraft.getInstance().player) {
            cir.setReturnValue(Config.PLAYER_COLOR);
        }
    }
}
