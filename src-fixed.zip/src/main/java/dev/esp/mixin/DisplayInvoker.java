package dev.esp.mixin;

import net.minecraft.world.entity.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Display.class)
public interface DisplayInvoker {
    @Invoker("setGlowColorOverride")
    void espSetGlowColor(int color);

    @Invoker("setViewRange")
    void espSetViewRange(float range);
}
