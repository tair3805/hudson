package dev.esp;

import net.minecraft.client.gui.GuiGraphics;

/** Общие примитивы отрисовки в стиле Krypton: скруглённые панели, таблетки-переключатели, иконки. */
final class Ui {
    static final int ORANGE = 0xFFFF8A3D;
    static final int PANEL = 0xF0151519, HEADER = 0xF00C0C10, SEP = 0xFF0D0D11;
    static final int TEXT = 0xFFE4E4E8, DIM = 0xFF8E8E98;
    static final int TW = 26, TH = 12;

    /** Панель/иконка: ступенчатое пиксельное скругление (радиус до 5px). */
    static void rounded(GuiGraphics g, int x, int y, int w, int h, int c) {
        roundRect(g, x, y, w, h, Math.min(5, h / 2), c);
    }

    /** Скруглены только верхние углы (шапка панели). */
    static void roundedTop(GuiGraphics g, int x, int y, int w, int h, int c) {
        int r = 5;
        for (int dy = 0; dy < h; dy++) {
            int inset = 0;
            if (dy < r) {
                double dyc = r - dy - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dyc * dyc)));
            }
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, c);
        }
    }

    /** Скруглённый прямоугольник с радиусом r (для r = h/2 получается "таблетка"). */
    static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        for (int dy = 0; dy < h; dy++) {
            int d = Math.min(dy, h - 1 - dy);
            int inset = 0;
            if (d < r) {
                double dyc = r - d - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dyc * dyc)));
            }
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, c);
        }
    }

    /** Переключатель как у Krypton: "таблетка" и круглый ползунок, края ступенчатые (по пикселям). */
    static void pill(GuiGraphics g, int x, int y, boolean on) {
        roundRect(g, x, y, TW, TH, TH / 2, on ? ORANGE : 0xFF2B2B34);
        int kd = TH - 2;
        int kx = on ? x + TW - kd - 1 : x + 1;
        roundRect(g, kx, y + 1, kd, kd, kd / 2, on ? 0xFFFFFFFF : 0xFFD0D0D8);
    }

    static int iconColor(String title) {
        return switch (title) {
            case "COMBAT" -> 0xFF9AA0AA;
            case "MOVEMENT" -> 0xFF5CD68A;
            case "RENDER" -> 0xFF5CC8E8;
            case "PLAYER" -> 0xFFB06CFF;
            case "MISC" -> 0xFFE0503C;
            default -> 0xFFE8C040;
        };
    }

    static void icon(GuiGraphics g, int x, int y, String title) {
        int c = iconColor(title);
        rounded(g, x, y, 10, 10, 0xFF1E1E24);
        rounded(g, x + 2, y + 2, 6, 6, c);
    }
}
