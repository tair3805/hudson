package dev.esp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;

/** Auto Relog: если игрок ниже заданного Y на мультиплеере, отключается и заходит на тот же сервер снова. */
public final class AutoRelog {
    public static boolean enabled = false;
    public static double yLevel = -4;
    public static int delaySec = 3;

    private static ServerData server;
    private static int countdown = -1;
    private static int grace = 0;

    public static void tick(Minecraft mc) {
        // ждём после отключения и заходим снова
        if (countdown >= 0) {
            if (mc.level != null) { countdown = -1; server = null; return; }
            if (--countdown <= 0) {
                countdown = -1;
                ServerData s = server;
                server = null;
                if (s != null) {
                    ConnectScreen.startConnecting(new JoinMultiplayerScreen(new TitleScreen()), mc,
                        ServerAddress.parseString(s.ip), s, false, null);
                }
            }
            return;
        }

        if (mc.level == null || mc.player == null) return;
        if (grace > 0) { grace--; return; }
        if (!enabled || mc.getCurrentServer() == null || mc.getConnection() == null) return;

        if (mc.player.getY() < yLevel) {
            server = mc.getCurrentServer();
            countdown = Math.max(1, delaySec) * 20;
            grace = 400; // защита от бесконечного релога, если спавн ниже порога
            mc.getConnection().getConnection().disconnect(Component.literal("Auto Relog"));
        }
    }
}
