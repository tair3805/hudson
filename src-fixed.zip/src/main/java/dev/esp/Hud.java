package dev.esp;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** HUD: список модулей, координаты, часы, скорость, эффекты, броня и цель. */
public final class Hud {
    public static boolean enabled = false, list = true, coords = true;
    public static boolean targetHud, armorHud, potionHud, speedometer, clock;

    private static final int TEXT = 0xFFE4E4E8, ORANGE_TXT = 0xFFFF9F5A, ORANGE = 0xFFFF8A3D;

    public static void render(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.level == null) return;
        Font f = mc.font;
        int w = g.guiWidth(), h = g.guiHeight();
        var p = mc.player;

        if (enabled && list) {
            List<String> names = Mods.ALL.stream()
                .filter(m -> m.get.getAsBoolean() && !m.name.equals("HUD"))
                .map(m -> m.name)
                .sorted(Comparator.comparingInt((String n) -> f.width(n)).reversed())
                .toList();
            int y = 4;
            for (String n : names) {
                int tw = f.width(n);
                g.fill(w - tw - 8, y - 1, w, y + 9, 0x90000000);
                g.fill(w - 2, y - 1, w, y + 9, ORANGE);
                g.drawString(f, n, w - tw - 5, y, ORANGE_TXT);
                y += 10;
            }
        }
        if (enabled && coords) {
            String s = String.format(Locale.ROOT, "XYZ %.1f %.1f %.1f", p.getX(), p.getY(), p.getZ());
            g.drawString(f, s, 4, h - 12, TEXT);
        }

        int y = 4;
        if (clock) {
            g.drawString(f, LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), 4, y, TEXT);
            y += 10;
        }
        if (speedometer) {
            double bps = p.getDeltaMovement().horizontalDistance() * 20.0;
            g.drawString(f, String.format(Locale.ROOT, "Скорость: %.2f б/с", bps), 4, y, TEXT);
            y += 10;
        }
        if (potionHud) {
            for (MobEffectInstance e : p.getActiveEffects()) {
                int secs = e.getDuration() / 20;
                String s = e.getEffect().value().getDisplayName().getString() + " " + (secs / 60) + ":" + String.format("%02d", secs % 60);
                g.drawString(f, s, 4, y, ORANGE_TXT);
                y += 10;
            }
        }
        if (armorHud) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            String[] names = {"Шлем", "Нагрудник", "Поножи", "Ботинки"};
            for (int i = 0; i < 4; i++) {
                ItemStack st = p.getItemBySlot(slots[i]);
                if (st.isEmpty() || st.getMaxDamage() <= 0) continue;
                g.drawString(f, names[i] + ": " + (st.getMaxDamage() - st.getDamageValue()) + "/" + st.getMaxDamage(), 4, y, TEXT);
                y += 10;
            }
        }
        if (targetHud) {
            Player best = null;
            double bd = 30 * 30;
            for (Player o : mc.level.players()) {
                if (o == p) continue;
                double d = p.distanceToSqr(o);
                if (d < bd) { bd = d; best = o; }
            }
            if (best != null) {
                int bx = w / 2 + 12, by = h / 2 + 12, bw = 90;
                g.fill(bx - 2, by - 2, bx + bw + 2, by + 24, 0xA0000000);
                g.drawString(f, best.getName().getString(), bx, by, TEXT);
                float hp = Math.max(0f, Math.min(best.getHealth(), best.getMaxHealth()));
                int fill = (int) (bw * (hp / Math.max(1f, best.getMaxHealth())));
                g.fill(bx, by + 12, bx + bw, by + 18, 0xFF2B2B34);
                g.fill(bx, by + 12, bx + fill, by + 18, ORANGE);
                g.drawString(f, String.format(Locale.ROOT, "%.1f", hp), bx + bw - f.width(String.format(Locale.ROOT, "%.1f", hp)), by, ORANGE_TXT);
            }
        }
    }
}
