package dev.esp;

import dev.esp.mixin.MinecraftAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Клиентские модули для тестов (обхода античитов здесь нет). */
public final class Modules {
    public static boolean fullbright, sprint, speed, step, fly, autoJump, glide;
    public static boolean killAura, killPlayers, autoTotem;
    public static boolean mobEsp, itemEsp;
    public static boolean fastPlace, autoTool, autoEat;
    public static boolean spider, highJump, bunnyHop, jesus, hover, fastFall, sneak;
    public static boolean animalEsp, zoom, autoRespawn, chestStealer, autoWalk, autoMine;
    public static boolean autoClicker, triggerBot, aimAssist, autoWeapon, autoArmor, triggerPlayers, aimPlayers;
    public static double jumpPower = 0.8, fallSpeed = 1.0, aimRange = 4.5, aimSpeed = 6.0;
    public static int cps = 10, zoomFov = 30, stealDelay = 2;
    private static boolean jumpArmed, prevSneak, prevWalk, prevMine, prevAnimal;
    private static int clickCd, stealCd, armorTick, savedFov = -1;
    public static boolean elytraBoost, longJump, waterSpeed, fastLadder, invCleaner;
    public static boolean projectileEsp, vehicleEsp, fovChanger, autoGapple, deathCoords;
    public static double elytraPower = 0.05, ljMult = 1.8, gappleHealth = 10;
    public static int fovValue = 90;
    private static boolean ljArmed, prevProj, prevVeh, gappling, deathShown;
    private static int cleanTick;
    public static float flySpeed = 0.1f;
    public static double speedMult = 1.25;
    public static double killRange = 3.0;
    public static double stepHeight = 1.0, glideFall = 0.1;
    public static int eatThreshold = 14, totemDelay = 5;

    private static boolean nightApplied, flyWasOn, prevMob, prevItem, eating;
    private static int totemCd;

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        var o = mc.options;
        Inventory inv = p.getInventory();
        boolean moving = o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown();
        Vec3 v = p.getDeltaMovement();

        if (fullbright) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            nightApplied = true;
        } else if (nightApplied) {
            p.removeEffect(MobEffects.NIGHT_VISION);
            nightApplied = false;
        }

        if (sprint && !Freecam.active && o.keyUp.isDown() && !p.isShiftKeyDown()
            && !p.horizontalCollision && p.getFoodData().getFoodLevel() > 6) p.setSprinting(true);

        if (speed && !Freecam.active && moving && p.onGround())
            p.setDeltaMovement(v.x * speedMult, v.y, v.z * speedMult);

        if (autoJump && !Freecam.active && moving && p.onGround() && p.horizontalCollision)
            p.setDeltaMovement(v.x, 0.42, v.z);

        if (glide && !p.onGround() && !p.isInWater() && !p.getAbilities().flying && v.y < -glideFall)
            p.setDeltaMovement(v.x, -glideFall, v.z);

        AttributeInstance stepAttr = p.getAttribute(Attributes.STEP_HEIGHT);
        if (stepAttr != null) stepAttr.setBaseValue(step ? stepHeight : 0.6);

        var ab = p.getAbilities();
        if (fly) {
            ab.mayfly = true; ab.flying = true; ab.setFlyingSpeed(flySpeed); flyWasOn = true;
        } else if (flyWasOn) {
            if (!p.isCreative() && !p.isSpectator()) { ab.mayfly = false; ab.flying = false; }
            ab.setFlyingSpeed(0.05f);
            flyWasOn = false;
        }

        if (fastPlace) ((MinecraftAccessor) mc).espSetRightClickDelay(0);

        if (autoTool && mc.screen == null && o.keyAttack.isDown()
            && mc.hitResult instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bh.getBlockPos());
            int best = inv.getSelectedSlot();
            float bs = inv.getItem(best).getDestroySpeed(st);
            for (int i = 0; i < 9; i++) {
                float s = inv.getItem(i).getDestroySpeed(st);
                if (s > bs) { bs = s; best = i; }
            }
            if (best != inv.getSelectedSlot()) inv.setSelectedSlot(best);
        }

        if (autoEat && mc.screen == null && !Freecam.active) {
            int slot = p.getFoodData().getFoodLevel() <= eatThreshold ? findFood(inv) : -1;
            if (slot != -1) { inv.setSelectedSlot(slot); o.keyUse.setDown(true); eating = true; }
            else if (eating) { o.keyUse.setDown(false); eating = false; }
        }

        // ---- движение: дополнительные модули ----
        Vec3 dv = p.getDeltaMovement();
        if (spider && !Freecam.active && moving && p.horizontalCollision) p.setDeltaMovement(dv.x, 0.2, dv.z);
        if (bunnyHop && !Freecam.active && moving && p.onGround()) p.setDeltaMovement(dv.x, 0.42, dv.z);
        if (highJump) {
            if (p.onGround()) jumpArmed = true;
            else if (jumpArmed && dv.y > 0) { p.setDeltaMovement(dv.x, jumpPower, dv.z); jumpArmed = false; }
        }
        if (jesus && p.isInWater() && !o.keyShift.isDown()) p.setDeltaMovement(dv.x, 0.2, dv.z);
        if (hover && !p.onGround() && !Freecam.active && !p.getAbilities().flying) {
            double hy = o.keyJump.isDown() ? 0.3 : (o.keyShift.isDown() ? -0.3 : 0.0);
            p.setDeltaMovement(dv.x, hy, dv.z);
        }
        if (fastFall && !p.onGround() && !p.isInWater() && dv.y < 0) p.setDeltaMovement(dv.x, Math.min(dv.y, -fallSpeed), dv.z);
        if (sneak && !Freecam.active) { o.keyShift.setDown(true); prevSneak = true; }
        else if (prevSneak) { o.keyShift.setDown(false); prevSneak = false; }

        if (elytraBoost && p.isFallFlying() && o.keyUp.isDown()) {
            Vec3 look = p.getLookAngle();
            Vec3 m = p.getDeltaMovement();
            p.setDeltaMovement(m.add(look.x * elytraPower, look.y * elytraPower, look.z * elytraPower));
        }
        if (longJump) {
            if (p.onGround()) ljArmed = true;
            else if (ljArmed && dv.y > 0) { ljArmed = false; p.setDeltaMovement(dv.x * ljMult, dv.y, dv.z * ljMult); }
        }
        if (waterSpeed && p.isInWater() && moving) {
            Vec3 m = p.getDeltaMovement();
            p.setDeltaMovement(m.x * 1.15, m.y, m.z * 1.15);
        }
        if (fastLadder && p.onClimbable() && o.keyUp.isDown() && p.horizontalCollision) {
            Vec3 m = p.getDeltaMovement();
            p.setDeltaMovement(m.x, 0.3, m.z);
        }

        // ---- игрок / разное ----
        if (autoRespawn && mc.screen instanceof DeathScreen) p.respawn();
        if (autoWalk && mc.screen == null) { o.keyUp.setDown(true); prevWalk = true; }
        else if (prevWalk) { o.keyUp.setDown(false); prevWalk = false; }
        if (autoMine && mc.screen == null) { o.keyAttack.setDown(true); prevMine = true; }
        else if (prevMine) { o.keyAttack.setDown(false); prevMine = false; }
        if (chestStealer && mc.gameMode != null && mc.screen instanceof ContainerScreen cs) {
            if (--stealCd <= 0) {
                stealCd = stealDelay;
                var menu = cs.getMenu();
                int n = menu.getRowCount() * 9;
                for (int i = 0; i < n; i++) {
                    if (!menu.getSlot(i).getItem().isEmpty()) {
                        mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, p);
                        break;
                    }
                }
            }
        }
        if (autoArmor && mc.gameMode != null && mc.screen == null && ++armorTick >= 10) { armorTick = 0; equipArmor(mc, p); }

        if (invCleaner && mc.gameMode != null && mc.screen == null && ++cleanTick >= 20) {
            cleanTick = 0;
            for (int i = 9; i <= 44; i++) {
                ItemStack st = p.inventoryMenu.getSlot(i).getItem();
                if (st.is(Items.ROTTEN_FLESH) || st.is(Items.SPIDER_EYE) || st.is(Items.POISONOUS_POTATO) || st.is(Items.BONE)) {
                    mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, 1, ClickType.THROW, p);
                    break;
                }
            }
        }
        if (deathCoords && mc.screen instanceof DeathScreen) {
            if (!deathShown) {
                deathShown = true;
                p.displayClientMessage(Component.literal(String.format(java.util.Locale.ROOT, "Смерть: %.0f %.0f %.0f",
                    p.getX(), p.getY(), p.getZ())), false);
            }
        } else deathShown = false;
        if (autoGapple && mc.screen == null && p.getHealth() <= gappleHealth) {
            int gs = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack st = inv.getItem(i);
                if (st.is(Items.GOLDEN_APPLE) || st.is(Items.ENCHANTED_GOLDEN_APPLE)) { gs = i; break; }
            }
            if (gs != -1) { inv.setSelectedSlot(gs); o.keyUse.setDown(true); gappling = true; }
            else if (gappling) { o.keyUse.setDown(false); gappling = false; }
        } else if (gappling) { o.keyUse.setDown(false); gappling = false; }

        // ---- бой: клик, триггер, прицел, оружие ----
        Entity looked = (mc.hitResult instanceof EntityHitResult ehr) ? ehr.getEntity() : null;
        if (autoClicker && mc.screen == null && mc.gameMode != null && o.keyAttack.isDown() && looked != null) {
            if (--clickCd <= 0) {
                clickCd = Math.max(1, 20 / Math.max(1, cps));
                mc.gameMode.attack(p, looked);
                p.swing(InteractionHand.MAIN_HAND);
            }
        } else clickCd = 0;
        if (triggerBot && mc.screen == null && mc.gameMode != null && looked != null
            && validTarget(looked, triggerPlayers) && p.getAttackStrengthScale(0.5f) >= 1f) {
            mc.gameMode.attack(p, looked);
            p.swing(InteractionHand.MAIN_HAND);
        }
        if (autoWeapon && mc.screen == null && o.keyAttack.isDown() && looked != null) {
            int sl = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack st = inv.getItem(i);
                if (st.is(ItemTags.SWORDS)) { sl = i; break; }
                if (sl == -1 && st.is(ItemTags.AXES)) sl = i;
            }
            if (sl != -1 && sl != inv.getSelectedSlot()) inv.setSelectedSlot(sl);
        }
        if (aimAssist && mc.screen == null && !Freecam.active && o.keyAttack.isDown()) aim(mc, p);

        // ---- рендер: зум ----
        if (zoom) {
            if (savedFov < 0) savedFov = o.fov().get();
            o.fov().set(zoomFov);
        } else if (fovChanger) {
            if (savedFov < 0) savedFov = o.fov().get();
            o.fov().set(fovValue);
        } else if (savedFov >= 0) {
            o.fov().set(savedFov);
            savedFov = -1;
        }

        // ---- подсветка мобов / животных / предметов ----
        if (mobEsp || itemEsp || animalEsp || projectileEsp || vehicleEsp
            || prevMob || prevItem || prevAnimal || prevProj || prevVeh) {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof Enemy) { if (mobEsp) e.setGlowingTag(true); else if (prevMob) e.setGlowingTag(false); }
                else if (e instanceof Mob) { if (animalEsp) e.setGlowingTag(true); else if (prevAnimal) e.setGlowingTag(false); }
                else if (e instanceof ItemEntity) { if (itemEsp) e.setGlowingTag(true); else if (prevItem) e.setGlowingTag(false); }
                else if (e instanceof Projectile) { if (projectileEsp) e.setGlowingTag(true); else if (prevProj) e.setGlowingTag(false); }
                else if (isVehicle(e)) { if (vehicleEsp) e.setGlowingTag(true); else if (prevVeh) e.setGlowingTag(false); }
            }
            prevMob = mobEsp; prevItem = itemEsp; prevAnimal = animalEsp; prevProj = projectileEsp; prevVeh = vehicleEsp;
        }

        if (killAura && !Freecam.active && mc.gameMode != null && p.getAttackStrengthScale(0.5f) >= 1f) {
            Entity best = null;
            double bd = killRange * killRange;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
                boolean isPlayer = e instanceof Player;
                if (isPlayer ? !killPlayers : !(e instanceof Enemy)) continue;
                double d = p.distanceToSqr(e);
                if (d < bd) { bd = d; best = e; }
            }
            if (best != null) { mc.gameMode.attack(p, best); p.swing(InteractionHand.MAIN_HAND); }
        }

        if (autoTotem && mc.gameMode != null && mc.screen == null) {
            if (totemCd > 0) totemCd--;
            else if (p.getOffhandItem().isEmpty()) {
                for (int i = 9; i <= 44; i++) {
                    if (p.inventoryMenu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) {
                        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, 40, ClickType.SWAP, p);
                        totemCd = totemDelay;
                        break;
                    }
                }
            }
        }
    }

    private static boolean isVehicle(Entity e) {
        var t = e.getType();
        return t.is(EntityTypeTags.BOAT) || t == EntityType.MINECART || t == EntityType.CHEST_MINECART
            || t == EntityType.FURNACE_MINECART || t == EntityType.HOPPER_MINECART || t == EntityType.TNT_MINECART;
    }

    private static boolean validTarget(Entity e, boolean players) {
        if (!(e instanceof LivingEntity le) || !le.isAlive()) return false;
        return e instanceof Player ? players : e instanceof Enemy;
    }

    private static void aim(Minecraft mc, LocalPlayer p) {
        Entity best = null;
        double bd = aimRange * aimRange;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == p || !validTarget(e, aimPlayers)) continue;
            double d = p.distanceToSqr(e);
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return;
        Vec3 t = best.getBoundingBox().getCenter().subtract(p.getEyePosition());
        float yaw = (float) (Mth.atan2(t.z, t.x) * 57.29577951308232) - 90f;
        float pitch = (float) -(Mth.atan2(t.y, Math.sqrt(t.x * t.x + t.z * t.z)) * 57.29577951308232);
        float dy = Mth.wrapDegrees(yaw - p.getYRot());
        float dp = pitch - p.getXRot();
        if (Math.abs(dy) > 70) return;
        float sp = (float) aimSpeed;
        p.setYRot(p.getYRot() + Mth.clamp(dy, -sp, sp));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dp, -sp, sp), -90f, 90f));
    }

    private static void equipArmor(Minecraft mc, LocalPlayer p) {
        for (int slot = 5; slot <= 8; slot++) {
            if (!p.inventoryMenu.getSlot(slot).getItem().isEmpty()) continue;
            EquipmentSlot need = switch (slot) {
                case 5 -> EquipmentSlot.HEAD;
                case 6 -> EquipmentSlot.CHEST;
                case 7 -> EquipmentSlot.LEGS;
                default -> EquipmentSlot.FEET;
            };
            for (int i = 9; i <= 44; i++) {
                ItemStack st = p.inventoryMenu.getSlot(i).getItem();
                var eq = st.get(DataComponents.EQUIPPABLE);
                if (eq == null || eq.slot() != need || st.is(Items.ELYTRA)) continue;
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, 0, ClickType.QUICK_MOVE, p);
                return;
            }
        }
    }

    private static int findFood(Inventory inv) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getItem(i);
            if (!s.has(DataComponents.FOOD)) continue;
            if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE) || s.is(Items.PUFFERFISH)
                || s.is(Items.POISONOUS_POTATO) || s.is(Items.SPIDER_EYE) || s.is(Items.ROTTEN_FLESH)
                || s.is(Items.CHORUS_FRUIT)) continue;
            return i;
        }
        return -1;
    }
}
