package dev.esp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.glfw.GLFW;

public class EspMod implements ClientModInitializer {
    static KeyMapping MENU;

    @Override
    public void onInitializeClient() {
        MENU = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.espmod.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));
        Mods.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (MENU.consumeClick()) mc.setScreen(new EspScreen());

            AutoRelog.tick(mc);
            Mods.tickBinds(mc);
            BlockEsp.tick(mc);
            Freecam.tick(mc);
            Modules.tick(mc);
            if (mc.level != null) {
                for (Player p : mc.level.players())
                    if (p != mc.player) p.setGlowingTag(Config.playerEsp);
            }
        });

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            Tracers.render(graphics, tickCounter);
            Hud.render(graphics, tickCounter);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            Freecam.active = false;
            BlockEsp.clear(null);
        });
    }
}
