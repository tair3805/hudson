package dev.esp;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** ClickGUI в стиле Krypton: все панели в один горизонтальный ряд (колесо мыши прокручивает, если не влезает). */
public class EspScreen extends Screen {
    private static final int PW = 138, RH = 16, HH = 18, GAP = 6, TOP = 24;

    private static final class Row {
        final String label; final BooleanSupplier on; final Runnable click; final Supplier<String> value; final Mods.Mod mod;
        Row(String label, BooleanSupplier on, Runnable click, Supplier<String> value, Mods.Mod mod) {
            this.label = label; this.on = on; this.click = click; this.value = value; this.mod = mod;
        }
    }

    private static final class Panel {
        final String title; final List<Row> rows = new ArrayList<>();
        int x, y;
        Panel(String title) { this.title = title; }
        int height() { return HH + rows.size() * RH + 2; }
    }

    private final List<Panel> panels = new ArrayList<>();
    private int scroll = 0, maxScroll = 0;

    public EspScreen() { super(Component.literal("Client")); }

    private void build() {
        panels.clear();
        for (Mods.Cat c : Mods.Cat.values()) {
            Panel p = new Panel(c.name());
            for (Mods.Mod m : Mods.ALL)
                if (m.cat == c) p.rows.add(new Row(m.name, m.get, m::toggle, null, m));
            panels.add(p);
        }

        // выбор блоков живёт в конце панели RENDER
        for (Panel pn : panels) {
            if (!pn.title.equals("RENDER")) continue;
            pn.rows.add(new Row("Выбор блоков…", null,
                () -> minecraft.setScreen(new BlockPickerScreen(this)),
                () -> (Config.CUSTOM.size() + Config.ENABLED.size()) + " выбр.", null));
            pn.rows.add(new Row("Выбрать все группы", null, () -> Config.ENABLED.addAll(Config.GROUPS), null, null));
            pn.rows.add(new Row("Снять всё", null, () -> { Config.ENABLED.clear(); Config.CUSTOM.clear(); }, null, null));
        }
    }

    private void hit(int x, int y, int w, Runnable r) {
        addRenderableWidget(Button.builder(Component.empty(), b -> r.run()).bounds(x, y, w, RH - 2).build());
    }

    @Override
    protected void init() {
        build();
        int n = panels.size();
        int total = n * (PW + GAP) - GAP;
        maxScroll = Math.max(0, total + 2 * GAP - width);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        int startX = maxScroll == 0 ? (width - total) / 2 : GAP - scroll;

        for (int i = 0; i < n; i++) {
            Panel p = panels.get(i);
            p.x = startX + i * (PW + GAP);
            p.y = TOP;
            for (int r = 0; r < p.rows.size(); r++) {
                Row row = p.rows.get(r);
                int ry = p.y + HH + r * RH + 1;
                if (row.mod != null) {
                    int gx = p.x + PW - Ui.TW - 6 - 13;
                    hit(p.x + 1, ry, gx - p.x - 2, row.click);
                    hit(gx, ry, 12, () -> minecraft.setScreen(new ModuleScreen(this, row.mod)));
                    hit(gx + 13, ry, p.x + PW - (gx + 13) - 1, row.click);
                } else {
                    hit(p.x + 1, ry, PW - 2, row.click);
                }
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (maxScroll > 0) {
            double d = Math.abs(scrollX) > Math.abs(scrollY) ? scrollX : scrollY;
            scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (d * 40)));
            rebuildWidgets();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x55000000);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);

        for (Panel p : panels) {
            Ui.rounded(g, p.x, p.y, PW, p.height(), Ui.PANEL);
            Ui.roundedTop(g, p.x, p.y, PW, HH, Ui.HEADER);
            Ui.icon(g, p.x + 5, p.y + 4, p.title);
            g.drawString(font, Component.literal(p.title).withColor(Ui.TEXT), p.x + 19, p.y + 5, 0xFFFFFFFF);
            g.drawString(font, Component.literal("▲").withColor(Ui.DIM), p.x + PW - 14, p.y + 5, 0xFFFFFFFF);

            for (int r = 0; r < p.rows.size(); r++) {
                Row row = p.rows.get(r);
                int ry = p.y + HH + r * RH;
                boolean hover = mx >= p.x && mx < p.x + PW && my >= ry && my < ry + RH;
                if (hover) g.fill(p.x + 1, ry, p.x + PW - 1, ry + RH, 0x14FFFFFF);
                if (r > 0) g.fill(p.x, ry, p.x + PW, ry + 1, Ui.SEP);

                g.drawString(font, Component.literal(row.label).withColor(Ui.TEXT), p.x + 6, ry + 4, 0xFFFFFFFF);

                if (row.on != null) {
                    int sx = p.x + PW - Ui.TW - 6;
                    Ui.pill(g, sx, ry + 2, row.on.getAsBoolean());

                    if (row.mod != null) {
                        int gx = sx - 13;
                        g.drawString(font, Component.literal("▼").withColor(Ui.DIM), gx + 2, ry + 3, 0xFFFFFFFF);
                        if (row.mod.key > 0) {
                            String k = Mods.keyName(row.mod.key);
                            g.drawString(font, Component.literal(k).withColor(0xFF9F5A), gx - 4 - font.width(k), ry + 4, 0xFFFFFFFF);
                        }
                    }
                } else if (row.value != null) {
                    String v = row.value.get();
                    g.drawString(font, Component.literal(v).withColor(0xFF9F5A), p.x + PW - 8 - font.width(v), ry + 4, 0xFFFFFFFF);
                }
            }
        }
        String hint = maxScroll > 0 ? "Колесо мыши — прокрутка  •  «▼» — настройки и бинд" : "«▼» — настройки и бинд модуля";
        g.drawCenteredString(font, Component.literal(hint).withColor(0x6B6F80), width / 2, height - 14, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        Mods.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
