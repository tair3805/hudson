package dev.esp;

import dev.esp.mixin.BlockDisplayInvoker;
import dev.esp.mixin.DisplayInvoker;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunkSection;

/** Block ESP (светящиеся BlockDisplay) и список целей для Block Tracers. */
public final class BlockEsp {
    private static final Map<BlockPos, Display.BlockDisplay> MARKERS = new HashMap<>();
    public static volatile Map<BlockPos, Integer> TARGETS = Map.of();
    private static final int MAX_MARKERS = 500;
    private static int nextId = -1_000_000;

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) { MARKERS.clear(); TARGETS = Map.of(); return; }
        boolean markers = Config.blockEsp || Config.storageEsp;
        if (!markers) clear(level);
        if (!markers && !Config.blockTracers) { TARGETS = Map.of(); return; }
        if (mc.player.tickCount % 20 != 0) return;

        BlockPos c = mc.player.blockPosition();
        int r = Config.radius;
        Predicate<BlockState> wanted = st -> Config.wantedColor(st.getBlock()) != -1;

        List<BlockPos> list = new ArrayList<>();
        int minSec = level.getMinSectionY();
        for (int cx = (c.getX() - r) >> 4; cx <= (c.getX() + r) >> 4; cx++) {
            for (int cz = (c.getZ() - r) >> 4; cz <= (c.getZ() + r) >> 4; cz++) {
                ChunkAccess ch = level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (ch == null) continue;
                LevelChunkSection[] secs = ch.getSections();
                for (int i = 0; i < secs.length; i++) {
                    LevelChunkSection sec = secs[i];
                    if (sec.hasOnlyAir() || !sec.maybeHas(wanted)) continue;
                    int by = (minSec + i) << 4;
                    for (int x = 0; x < 16; x++)
                        for (int y = 0; y < 16; y++)
                            for (int z = 0; z < 16; z++) {
                                if (!wanted.test(sec.getBlockState(x, y, z))) continue;
                                BlockPos pos = new BlockPos((cx << 4) + x, by + y, (cz << 4) + z);
                                if (Math.abs(pos.getX() - c.getX()) <= r && Math.abs(pos.getY() - c.getY()) <= r
                                    && Math.abs(pos.getZ() - c.getZ()) <= r) list.add(pos);
                            }
                }
            }
        }
        list.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
        Map<BlockPos, Integer> found = new LinkedHashMap<>();
        for (BlockPos p : list) {
            if (found.size() >= MAX_MARKERS) break;
            found.put(p, Config.wantedColor(level.getBlockState(p).getBlock()));
        }
        TARGETS = found;
        if (!markers) return;

        MARKERS.entrySet().removeIf(e -> {
            if (found.containsKey(e.getKey())) return false;
            level.removeEntity(e.getValue().getId(), Entity.RemovalReason.DISCARDED);
            return true;
        });

        for (Map.Entry<BlockPos, Integer> e : found.entrySet()) {
            if (MARKERS.containsKey(e.getKey())) continue;
            BlockPos p = e.getKey();
            Display.BlockDisplay d = new Display.BlockDisplay(EntityType.BLOCK_DISPLAY, level);
            d.setId(nextId--);
            d.setPos(p.getX(), p.getY(), p.getZ());
            ((BlockDisplayInvoker) d).espSetBlockState(level.getBlockState(p));
            ((DisplayInvoker) d).espSetGlowColor(e.getValue());
            ((DisplayInvoker) d).espSetViewRange(Config.radius / 64f + 0.5f);
            d.setGlowingTag(true);
            level.addEntity(d);
            MARKERS.put(p, d);
        }
    }

    public static void clear(ClientLevel level) {
        if (level != null)
            for (Display.BlockDisplay d : MARKERS.values())
                level.removeEntity(d.getId(), Entity.RemovalReason.DISCARDED);
        MARKERS.clear();
    }
}
